package com.babbel.testing

class GetUserUseCase {
    fun getUserName(): String = "John Doe"
}